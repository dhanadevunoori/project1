body{margin:0 auto;padding:0 auto;}

.header{
	float:left;
	text-align:center;
	width:100%;background-color:black;
	color:white;
}
.menu li{
	display:inline
}
.specials_section{float:left;width:100%;}

.specials_section h3{
font-family: "Raleway", sans-serif; 
font-size:3px;font-weight:400;text-align:center;} 
.story_session{float:left;width:100%}
.story_session_part1{float:left;width:50%}
.story_session_part1 img(width:80%;}
.story_session_part2{float:right;}
.story_session_part2 h4{
	font-family:"raleway",sans-serif;
	font-size:24px;
	font-weight:400;
	}
.story_session_part2 p{
font-family:"raleway",sans-serif;
font-size:15px;
font-weight:400;}
.address{float:left;width:100%}
.footer{float:left;width:100%;
background-color:black;
color:white;text-align:center;}
.socialmedia{display:inline}
